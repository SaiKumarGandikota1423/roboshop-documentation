# DevOps with AWS - 78S

#### Language: Telugu
#### Trainer: Sivakumar Reddy
#### Demo: 31-MAR-2024 10:30AM IST
#### Classes: 01-APR-2024 07:15-08:45AM IST
#### Duration: 120 Hours, 3.5 Months, MON-FRI

#### Session Link: https://tally.so/r/wvAdjl

### AWS Account Creation

https://www.youtube.com/watch?v=F4jF88UkxV4

https://portal.aws.amazon.com/billing/signup

### DevOps overview sessions

https://www.youtube.com/watch?v=iO8qpPeiph0&list=PLbeIORXauosjypPNHf4YGeEKN3KlSjzOj


